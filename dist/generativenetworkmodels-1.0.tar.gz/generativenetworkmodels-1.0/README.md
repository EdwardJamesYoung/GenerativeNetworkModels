# Weighted Generative Network Model Toolbox

[Read the full documentation](https://generative-network-models-toolbox.readthedocs.io/en/latest/)